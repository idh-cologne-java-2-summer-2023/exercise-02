package idh.java;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ATM {
	int accountBalance = 100;
	int ATMCash = 5000;
	int withdraw = 21;
	int accountNumber = 123;

	public void cashout(int amount) {

		if (amount < accountBalance) {
			accountBalance = accountBalance - amount;
			ATMCash - amount;
			System.out.println("Ok, here is your money, enjoy!");
		} else if (ATMCash  <= amount) {
			System.out.println("Sorry, the ATM doesn't have that much cash anymore.");
		}
		else {
			System.out.println("Sorry, not enough money in the bank.");
		}
	}
	public void account() {
		System.out.println("Enter your account number: ");
	}
	public void run() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			try {
				System.out.print("Enter the amount to withdraw: ");
				int amount = Integer.parseInt(br.readLine());
				cashout(amount);
			} catch (Exception e) {
				break;
			}
		}
	}
	public static void main(String[] args) {
		ATM atm = new ATM();
		atm.run();
	}

}
